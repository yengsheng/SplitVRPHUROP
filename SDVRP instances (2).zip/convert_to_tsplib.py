# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 12:05:55 2020

@author: Yong Sheng
"""
import os

def convert(filename):
    f = open(filename)
    lines = f.readlines()
    nodes, capacity = lines[0].strip().split()
    nodes = int(nodes) + 1
    demands = ['0'] + lines[1].strip().split()
    locs = lines[2:]
    locs_stripped = []
    for i in locs:
        x = i.strip().split()
        temp = []
        for j in x:
            temp.append(int(j))
        locs_stripped.append(temp)
    init_x, init_y = locs_stripped[0]
    for i in locs_stripped[1:]:
        i[0] -= init_x
        i[1] -= init_y
    locs_stripped[0] = [0, 0]
    final = "NAME: " + filename[0:-4] + '\n' + 'BEST_KNOWN: 0\nCOMMENT: 0\nDIMENSION: ' + str(nodes) + '\nCAPACITY: ' + capacity + '\nEDGE_WEIGHT_FORMAT: FUNCTION\nEDGE_WEIGHT_TYPE: EXACT_2D\n'
    node_coord_section = 'NODE_COORD_SECTION\n'
    for i in range(1, nodes + 1):
        node_coord_section += str(i) + ' ' + str(locs_stripped[i-1][0]) + ' ' + str(locs_stripped[i-1][1]) + '\n'
    node_coord_section += 'DEMAND_SECTION\n'
    for i in range(1, nodes + 1):
        node_coord_section += str(i) + ' ' + demands[i-1] + '\n'
    node_coord_section += 'DEPOT_SECTION\n1\n-1\nEOF\n'
    
    index_check = 0
    while os.path.isfile(filename[0:-4] + "_tsplib" + str(index_check) + ".txt"):
        index_check += 1
    f = open(filename[0:-4] + "_tsplib" + str(index_check) + ".txt", "x")
    f.write(final)
    f.write(node_coord_section)
    f.close()
dirs = tuple(os.walk('.\\SDVRP instances'))
for i in dirs[1:]:
    for j in i[2]:
        convert(i[0] + '\\' + j)
'''
NAME: Christofides-1
BEST_KNOWN: 524.61
COMMENT: 524.610000
DIMENSION: 51
CAPACITY: 160
EDGE_WEIGHT_FORMAT: FUNCTION
EDGE_WEIGHT_TYPE: EXACT_2D
NODE_COORD_SECTION
1 0.00000 0.00000
2 7.00000 12.00000
3 19.00000 9.00000
4 22.00000 24.00000
5 -10.00000 -14.00000
6 10.00000 -10.00000
7 -9.00000 7.00000
8 -13.00000 23.00000
9 1.00000 22.00000
10 22.00000 -7.00000
11 21.00000 -19.00000
12 12.00000 1.00000
13 1.00000 -8.00000
14 -25.00000 -15.00000
15 -18.00000 2.00000
16 6.00000 -24.00000
17 22.00000 1.00000
18 -3.00000 -17.00000
19 -13.00000 -7.00000
20 -17.00000 -27.00000
21 27.00000 18.00000
22 32.00000 2.00000
23 12.00000 17.00000
24 -14.00000 17.00000
25 -22.00000 12.00000
26 -23.00000 -2.00000
27 -3.00000 28.00000
28 0.00000 8.00000
29 13.00000 27.00000
30 28.00000 8.00000
31 28.00000 -13.00000
32 7.00000 29.00000
33 8.00000 6.00000
34 16.00000 -30.00000
35 31.00000 -7.00000
36 32.00000 23.00000
37 33.00000 29.00000
38 2.00000 -18.00000
39 15.00000 -5.00000
40 29.00000 -25.00000
41 -25.00000 -34.00000
42 -20.00000 -23.00000
43 -9.00000 -30.00000
44 -25.00000 24.00000
45 0.00000 -25.00000
46 9.00000 -30.00000
47 2.00000 -1.00000
48 -5.00000 -8.00000
49 -5.00000 15.00000
50 18.00000 -12.00000
51 26.00000 -3.00000
DEMAND_SECTION
1 0
2 7
3 30
4 16
5 9
6 21
7 15
8 19
9 23
10 11
11 5
12 19
13 29
14 23
15 21
16 10
17 15
18 3
19 41
20 9
21 28
22 8
23 8
24 16
25 10
26 28
27 7
28 15
29 14
30 6
31 19
32 11
33 12
34 23
35 26
36 17
37 6
38 9
39 15
40 14
41 7
42 27
43 13
44 11
45 16
46 10
47 5
48 25
49 17
50 18
51 10
DEPOT_SECTION
1
-1
EOF

'''