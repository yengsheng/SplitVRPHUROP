import subprocess
#subprocess.Popen('powershell.exe cd .\\Desktop\\UROP\\SplitVRPHUROP')
subprocess.Popen('powershell.exe .\\vrp_rtr.exe -f p01_00_tsplib2.txt -out testpenis_output.txt', cwd = 'C:\\Users\\Yong Sheng\\Desktop\\UROP\\SplitVRPHUROP')

